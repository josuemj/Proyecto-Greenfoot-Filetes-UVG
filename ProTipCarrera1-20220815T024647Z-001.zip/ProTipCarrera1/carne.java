import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class carne here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class carne extends Actor
{
    public int speed;
    public carne(int v){
        speed = v;
    }

    /**
     * Act - do whatever the carne wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        // Add your action code here.
        if(Greenfoot.isKeyDown("right")){
            if(getX() < 450)
                 setLocation(getX() + speed, getY());
        }
        if(Greenfoot.isKeyDown("left")){
            if(getX() > 50)
                 setLocation(getX() - speed, getY());
        }
        if(Greenfoot.isKeyDown("up")){
             if(getY()>100)
                 setLocation(getX() , getY() - speed);
        }
        if(Greenfoot.isKeyDown("down")){
             if(getY()<640)
             setLocation(getX() , getY() + speed);
        }
        checkCollision(); 
    }
    public void checkCollision(){
        Actor collided = getOneIntersectingObject(tenedor.class);
        if (collided != null)
        {
            World world = getWorld();
            getWorld().removeObject(collided);
            getWorld().removeObjects(world.getObjects(null));
            world.addObject(new GameOver(), world.getWidth()/2, world.getHeight()/2);
            Greenfoot.stop();
        }
    }
    public void aumenta_velocidad(){
        speed++;
    }
}

